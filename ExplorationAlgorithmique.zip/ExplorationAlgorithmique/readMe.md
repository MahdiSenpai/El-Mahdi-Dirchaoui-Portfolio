# Exploration algorithmique
Situation d'Apprentissage et d'Évaluation S2.02
- Exploration algorithmique d'un problème 

BUT Informatique 1ère année semestre 2 de l'IUT de Bayonne et du Pays Basque.

## Equipe projet
- Kessentini Nour
- Laborde Romain