# Exploration algorithmique
Situation d'Apprentissage et d'Évaluation S2.02
- Exploration algorithmique d'un problème 

BUT Informatique 

## Equipe projet
- Kessentini Nour
- Laborde Romain
- Dirchaoui El Mahdi